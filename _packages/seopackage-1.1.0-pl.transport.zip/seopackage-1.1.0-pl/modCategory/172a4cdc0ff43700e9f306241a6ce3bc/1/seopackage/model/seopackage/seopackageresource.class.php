<?php

/**
 * SEO Package
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

class SeoPackageResource extends xPDOSimpleObject
{
}

<?php

/**
 * SEO Package
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/seopackageresource.class.php';

class SeoPackageResource_mysql extends SeoPackageResource
{
}

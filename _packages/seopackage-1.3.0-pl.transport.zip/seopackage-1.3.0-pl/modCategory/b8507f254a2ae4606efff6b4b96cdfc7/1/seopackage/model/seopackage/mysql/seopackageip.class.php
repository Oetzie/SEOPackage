<?php

/**
 * SEO Package
 *
 * Copyright 2020 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/seopackageip.class.php';

class SeoPackageIP_mysql extends SeoPackageIP
{
}
